const yesButton = document.getElementById("yesButton");
const noButton = document.getElementById("noButton");

let yesSize = 1;  // Track the button size

// Event listener for the "NO" button
noButton.addEventListener("click", () => {
    // Increase the size of the YES button each time NO is clicked
    yesSize += 0.2; // Increase size by 20%
    yesButton.style.transform = `scale(${yesSize})`;

    // Play the boo sound when NO is clicked
    const booSound = new Audio('https://www.soundjay.com/button/beep-07.wav'); // Replace with your own boo sound URL
    booSound.play();
});

// Event listener for the "YES" button
yesButton.addEventListener("click", () => {
    // Play the cheering sound when YES is clicked
    const cheerSound = new Audio('https://www.soundjay.com/button/button-16.wav'); // Replace with your own cheering sound URL
    cheerSound.play();
});
